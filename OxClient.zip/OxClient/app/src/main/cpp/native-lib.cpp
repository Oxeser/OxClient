#include <jni.h>
#include <string>
#include <android/log.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <dlfcn.h>
#include <link.h>

#define LOG_TAG "OxClient-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Global variables
static JavaVM* g_jvm = nullptr;
static jobject g_context = nullptr;
static bool g_initialized = false;

// Minecraft process info
static pid_t minecraft_pid = 0;
static void* minecraft_base = nullptr;

// Function prototypes
extern "C" {
    JNIEXPORT void JNICALL Java_com_oxclient_MainActivity_initializeNative(JNIEnv *env, jobject thiz);
    JNIEXPORT void JNICALL Java_com_oxclient_MainActivity_cleanupNative(JNIEnv *env, jobject thiz);
    JNIEXPORT jboolean JNICALL Java_com_oxclient_MainActivity_isMinecraftRunning(JNIEnv *env, jobject thiz);
    JNIEXPORT void JNICALL Java_com_oxclient_MainActivity_injectIntoMinecraft(JNIEnv *env, jobject thiz);
}

// Utility functions
pid_t find_minecraft_process() {
    FILE* fp = popen("ps | grep com.mojang.minecraftpe", "r");
    if (fp == nullptr) {
        return 0;
    }
    
    char line[256];
    pid_t pid = 0;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "com.mojang.minecraftpe")) {
            sscanf(line, "%*s %d", &pid);
            break;
        }
    }
    
    pclose(fp);
    return pid;
}

void* get_module_base(pid_t pid, const char* module_name) {
    char maps_path[64];
    snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);
    
    FILE* fp = fopen(maps_path, "r");
    if (fp == nullptr) {
        return nullptr;
    }
    
    char line[512];
    void* base_addr = nullptr;
    
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, module_name)) {
            sscanf(line, "%p", &base_addr);
            break;
        }
    }
    
    fclose(fp);
    return base_addr;
}

// Memory manipulation functions
bool write_memory(pid_t pid, void* addr, const void* data, size_t size) {
    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) == -1) {
        return false;
    }
    
    waitpid(pid, nullptr, 0);
    
    for (size_t i = 0; i < size; i += sizeof(long)) {
        long word = 0;
        memcpy(&word, (char*)data + i, 
               (size - i >= sizeof(long)) ? sizeof(long) : (size - i));
        
        if (ptrace(PTRACE_POKEDATA, pid, (char*)addr + i, word) == -1) {
            ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
            return false;
        }
    }
    
    ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
    return true;
}

bool read_memory(pid_t pid, void* addr, void* buffer, size_t size) {
    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) == -1) {
        return false;
    }
    
    waitpid(pid, nullptr, 0);
    
    for (size_t i = 0; i < size; i += sizeof(long)) {
        long word = ptrace(PTRACE_PEEKDATA, pid, (char*)addr + i, nullptr);
        if (word == -1) {
            ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
            return false;
        }
        
        memcpy((char*)buffer + i, &word, 
               (size - i >= sizeof(long)) ? sizeof(long) : (size - i));
    }
    
    ptrace(PTRACE_DETACH, pid, nullptr, nullptr);
    return true;
}

// Hook functions for KillAura
void setup_killaura_hooks() {
    if (minecraft_pid == 0 || minecraft_base == nullptr) {
        LOGE("Minecraft not found, cannot setup hooks");
        return;
    }
    
    LOGI("Setting up KillAura hooks for PID: %d", minecraft_pid);
    
    // Example: Hook attack function
    // This would need to be adjusted based on actual Minecraft PE offsets
    void* attack_func_addr = (char*)minecraft_base + 0x123456; // Example offset
    
    // Create hook payload (simplified)
    unsigned char hook_code[] = {
        0x00, 0x00, 0x00, 0x00  // Placeholder for actual hook code
    };
    
    if (write_memory(minecraft_pid, attack_func_addr, hook_code, sizeof(hook_code))) {
        LOGI("Attack function hook installed successfully");
    } else {
        LOGE("Failed to install attack function hook");
    }
}

void setup_rotation_hooks() {
    if (minecraft_pid == 0 || minecraft_base == nullptr) {
        return;
    }
    
    LOGI("Setting up rotation hooks");
    
    // Example: Hook player rotation function
    void* rotation_func_addr = (char*)minecraft_base + 0x789ABC; // Example offset
    
    unsigned char hook_code[] = {
        0x00, 0x00, 0x00, 0x00  // Placeholder
    };
    
    if (write_memory(minecraft_pid, rotation_func_addr, hook_code, sizeof(hook_code))) {
        LOGI("Rotation function hook installed successfully");
    } else {
        LOGE("Failed to install rotation function hook");
    }
}

// JNI Implementation
JNIEXPORT void JNICALL Java_com_oxclient_MainActivity_initializeNative(JNIEnv *env, jobject thiz) {
    if (g_initialized) {
        return;
    }
    
    env->GetJavaVM(&g_jvm);
    g_context = env->NewGlobalRef(thiz);
    
    LOGI("Native library initialized");
    g_initialized = true;
}

JNIEXPORT void JNICALL Java_com_oxclient_MainActivity_cleanupNative(JNIEnv *env, jobject thiz) {
    if (!g_initialized) {
        return;
    }
    
    if (g_context) {
        env->DeleteGlobalRef(g_context);
        g_context = nullptr;
    }
    
    g_jvm = nullptr;
    g_initialized = false;
    
    LOGI("Native library cleaned up");
}

JNIEXPORT jboolean JNICALL Java_com_oxclient_MainActivity_isMinecraftRunning(JNIEnv *env, jobject thiz) {
    minecraft_pid = find_minecraft_process();
    return (minecraft_pid != 0) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_oxclient_MainActivity_injectIntoMinecraft(JNIEnv *env, jobject thiz) {
    minecraft_pid = find_minecraft_process();
    
    if (minecraft_pid == 0) {
        LOGE("Minecraft process not found");
        return;
    }
    
    LOGI("Found Minecraft process: %d", minecraft_pid);
    
    // Get Minecraft base address
    minecraft_base = get_module_base(minecraft_pid, "libminecraftpe.so");
    if (minecraft_base == nullptr) {
        LOGE("Could not find Minecraft base address");
        return;
    }
    
    LOGI("Minecraft base address: %p", minecraft_base);
    
    // Setup hooks
    setup_killaura_hooks();
    setup_rotation_hooks();
    
    LOGI("Injection completed successfully");
}

// Additional utility functions for module support
extern "C" JNIEXPORT jfloat JNICALL
Java_com_oxclient_utils_EntityUtils_getEntityHealth(JNIEnv *env, jclass clazz, jobject entity) {
    // Implementation would read entity health from memory
    return 20.0f; // Placeholder
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_oxclient_utils_EntityUtils_getDistanceToEntity(JNIEnv *env, jclass clazz, jobject entity) {
    // Implementation would calculate distance
    return 4.0f; // Placeholder
}

extern "C" JNIEXPORT void JNICALL
Java_com_oxclient_utils_EntityUtils_attackEntity(JNIEnv *env, jclass clazz, jobject entity) {
    // Implementation would trigger attack
    LOGI("Attacking entity (native)");
}

extern "C" JNIEXPORT void JNICALL
Java_com_oxclient_utils_RotationUtils_setPlayerRotations(JNIEnv *env, jclass clazz, jfloat yaw, jfloat pitch) {
    // Implementation would set player rotations
    LOGI("Setting player rotation: yaw=%.2f, pitch=%.2f", yaw, pitch);
}